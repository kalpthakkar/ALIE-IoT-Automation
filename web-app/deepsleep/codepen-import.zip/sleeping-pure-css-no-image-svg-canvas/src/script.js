/*
    ** ِ This code is dedicaded to my eager students ♥ **

    Authors:
      • An amazing illustration by Nick Slater(https://dribbble.com/slaterdesign)
    
      • Made with pure css (no image) and ♥ by Alireza Sheikholmolouki
    (https://twitter.com/alireza29675, http://alireza.sheikholmolouki.com)
*/